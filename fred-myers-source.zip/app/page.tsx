"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Mode = "title" | "playing" | "won" | "lost";
type Entity = { x: number; y: number; vx?: number; vy?: number; r: number; kind: string; eaten?: boolean };

const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
const distance = (a: {x:number;y:number}, b: {x:number;y:number}) => Math.hypot(a.x-b.x,a.y-b.y);

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<any>(null);
  const [mode, setMode] = useState<Mode>("title");
  const [chapter, setChapter] = useState(1);
  const [bugs, setBugs] = useState(0);
  const [energy, setEnergy] = useState(100);
  const [hearts, setHearts] = useState(3);
  const [underwater, setUnderwater] = useState(false);
  const [message, setMessage] = useState("Reach the moonlit lily gate");
  const [levelFlash, setLevelFlash] = useState("LEVEL 1 · LILY LEAP");

  const startGame = useCallback(() => {
    const pads: Entity[] = Array.from({length: 18}, (_,i) => ({
      x: 90 + (i%6)*160 + (i%2)*35, y: 160 + Math.floor(i/6)*190 + Math.sin(i)*35, r: 42 + (i%3)*5, kind:"pad"
    }));
    const bugList: Entity[] = Array.from({length: 14}, (_,i) => ({x: 120+(i*149)%860,y:110+(i*97)%520,r:9,kind:i%4===0?"firefly":"bug"}));
    gameRef.current = {
      fred:{x:100,y:520,vx:0,vy:0,r:22}, target:{x:100,y:520}, pads, bugs:bugList,
      predators:[{x:850,y:140,vx:-0.7,vy:0.4,r:31,kind:"heron"},{x:720,y:580,vx:-0.4,vy:-0.55,r:27,kind:"snake"}],
      fish:[{x:250,y:250,vx:1.4,vy:.3,r:28,kind:"pike"},{x:760,y:400,vx:-1.2,vy:-.2,r:25,kind:"bass"}],
      holes:[{x:330,y:620,r:30,kind:"hole"},{x:880,y:510,r:30,kind:"hole"}],
      keys:{}, energy:100, hearts:3, bugCount:0, chapter:1, underwater:false, invincible:0, time:0, pulse:0
    };
    setChapter(1); setBugs(0); setEnergy(100); setHearts(3); setUnderwater(false);
    setMessage("Eat 4 bugs, then reach the moonlit lily gate"); setLevelFlash("LEVEL 1 · LILY LEAP"); setMode("playing");
    window.setTimeout(()=>setLevelFlash(""),1800);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let raf = 0; let last = performance.now();
    const resize = () => { const dpr=Math.min(devicePixelRatio,2); const box=canvas.getBoundingClientRect(); canvas.width=box.width*dpr;canvas.height=box.height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0); };
    resize(); window.addEventListener("resize",resize);

    const pointer = (ev: PointerEvent) => {
      if(mode!=="playing"||!gameRef.current)return;
      const b=canvas.getBoundingClientRect(); const g=gameRef.current;
      g.target.x=(ev.clientX-b.left)/b.width*1000; g.target.y=(ev.clientY-b.top)/b.height*700;
      if(distance(g.fred,g.target)<95){ const bug=g.bugs.find((x:Entity)=>!x.eaten&&distance(x,g.fred)<95); if(bug){bug.eaten=true;g.bugCount++;g.energy=Math.min(100,g.energy+18);setBugs(g.bugCount);setMessage(g.bugCount<4?`${4-g.bugCount} bugs until the gate awakens!`:"The Moonpetal Gate is open — head northeast!");}}
    };
    canvas.addEventListener("pointerdown",pointer);
    const kd=(e:KeyboardEvent)=>{if(!gameRef.current)return;gameRef.current.keys[e.key.toLowerCase()]=true;if([" ","arrowup","arrowdown","arrowleft","arrowright"].includes(e.key.toLowerCase()))e.preventDefault();};
    const ku=(e:KeyboardEvent)=>{if(gameRef.current)gameRef.current.keys[e.key.toLowerCase()]=false;};
    window.addEventListener("keydown",kd);window.addEventListener("keyup",ku);

    const draw = (now:number) => {
      const w=canvas.clientWidth,h=canvas.clientHeight;ctx.clearRect(0,0,w,h);
      const sx=w/1000,sy=h/700;ctx.save();ctx.scale(sx,sy);
      const g=gameRef.current;
      const grad=ctx.createLinearGradient(0,0,0,700);grad.addColorStop(0,g?.underwater?"#073f50":"#72d6d0");grad.addColorStop(1,g?.underwater?"#031b33":"#0f5863");ctx.fillStyle=grad;ctx.fillRect(0,0,1000,700);
      for(let i=0;i<34;i++){ctx.globalAlpha=.14;ctx.fillStyle=i%2?"#fff":"#b8ffd7";ctx.beginPath();ctx.ellipse((i*83+(g?.time||0)*4)%1100-50,80+(i*71)%570,55,4,0,0,Math.PI*2);ctx.fill();}
      ctx.globalAlpha=1;
      if(g){
        const dt=Math.min(2,(now-last)/16.67);last=now;g.time+=dt/60;g.pulse+=dt;
        if(mode==="playing"){
          const f=g.fred,k=g.keys;let dx=(k.arrowright||k.d?1:0)-(k.arrowleft||k.a?1:0),dy=(k.arrowdown||k.s?1:0)-(k.arrowup||k.w?1:0);
          if(!dx&&!dy){dx=g.target.x-f.x;dy=g.target.y-f.y;const mag=Math.hypot(dx,dy);if(mag<8){dx=dy=0}else{dx/=mag;dy/=mag;}}
          const boost=(k[" "]||k.shift)&&g.energy>0;const speed=(g.underwater?2.35:2.8)*(boost?2.15:1);if(boost){g.energy=Math.max(0,g.energy-dt*.75)}else g.energy=Math.min(100,g.energy+dt*.12);
          f.vx+=(dx*speed-f.vx)*.12;f.vy+=(dy*speed-f.vy)*.12;f.x=clamp(f.x+f.vx*dt,22,978);f.y=clamp(f.y+f.vy*dt,25,675);
          if(k.q){g.underwater=true;setUnderwater(true)} if(k.e){g.underwater=false;setUnderwater(false)}
          const activePredators=g.underwater?g.fish:g.predators;
          activePredators.forEach((p:Entity)=>{let d=distance(p,f);if(d<230){p.vx!+=(f.x-p.x)/Math.max(d,1)*.035*dt;p.vy!+=(f.y-p.y)/Math.max(d,1)*.035*dt;}p.x+=(p.vx||0)*dt;p.y+=(p.vy||0)*dt;if(p.x<20||p.x>980)p.vx=-(p.vx||0);if(p.y<30||p.y>670)p.vy=-(p.vy||0);if(d<p.r+f.r&&g.invincible<=0){g.hearts--;g.invincible=120;f.x=100;f.y=560;g.energy=45;setHearts(g.hearts);setMessage(g.underwater?"A fish nearly swallowed Fred! Boost and weave!":"Too close! Hide, dive, or boost away!");if(g.hearts<=0)setMode("lost");}});
          g.holes.forEach((hole:Entity)=>{if(!g.underwater&&distance(hole,f)<hole.r+8){g.invincible=Math.max(g.invincible,30);g.energy=Math.min(100,g.energy+.3*dt);}});
          if(g.invincible>0)g.invincible-=dt;
          g.bugs.forEach((b:Entity)=>{if(!b.eaten){b.y+=Math.sin(g.time*4+b.x)*.15;if(distance(b,f)<35){b.eaten=true;g.bugCount++;g.energy=Math.min(100,g.energy+16);setBugs(g.bugCount);}}});
          const advance=(n:number,title:string,msg:string,x:number,y:number)=>{g.chapter=n;setChapter(n);setMessage(msg);setLevelFlash(`LEVEL ${n} · ${title}`);window.setTimeout(()=>setLevelFlash(""),1800);f.x=x;f.y=y;g.target={x,y};g.energy=Math.min(100,g.energy+30);};
          if(g.chapter===1&&g.bugCount>=4&&f.x>900&&f.y<130){advance(2,"THE DEEP","Dive for the Sunken Acorn — fish are faster below",500,100);g.underwater=true;setUnderwater(true);}
          if(g.chapter===2&&g.underwater&&f.x>450&&f.x<570&&f.y>570){advance(3,"FIREFLY FEN","Eat 4 more bugs and cross the glowing eastern gate",90,600);g.underwater=false;setUnderwater(false);g.predators.push({x:520,y:100,vx:.5,vy:.7,r:29,kind:"heron"});}
          if(g.chapter===3&&g.bugCount>=8&&f.x>900&&f.y<150){advance(4,"PREDATOR PASS","Carry the acorn to the western hollow without being caught",920,600);g.predators.push({x:600,y:540,vx:-.8,vy:-.2,r:30,kind:"snake"});}
          if(g.chapter===4&&!g.underwater&&f.x<95&&f.y<150){advance(5,"MOONPETAL RISE","Final leap: reach the Moonpetal at the north shore",500,630);}
          if(g.chapter===5&&!g.underwater&&f.y<85&&f.x>420&&f.x<580)setMode("won");
          setEnergy(Math.round(g.energy));
        }
        const shadow=(x:number,y:number,r:number)=>{ctx.fillStyle="rgba(0,18,25,.24)";ctx.beginPath();ctx.ellipse(x,y+r*.8,r*1.1,r*.3,0,0,Math.PI*2);ctx.fill();};
        if(!g.underwater){
          g.pads.forEach((p:Entity,i:number)=>{shadow(p.x,p.y,p.r);const pg=ctx.createRadialGradient(p.x-10,p.y-15,4,p.x,p.y,p.r);pg.addColorStop(0,"#b8f26e");pg.addColorStop(1,"#297a46");ctx.fillStyle=pg;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*1.82);ctx.lineTo(p.x,p.y);ctx.fill();if(i%5===0){ctx.fillStyle="#ff85c8";ctx.beginPath();ctx.arc(p.x,p.y-8,9,0,Math.PI*2);ctx.fill();}});
          g.holes.forEach((p:Entity)=>{ctx.fillStyle="#142f22";ctx.beginPath();ctx.ellipse(p.x,p.y,p.r,p.r*.55,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#8ad06a";ctx.lineWidth=5;ctx.stroke();});
        } else { for(let i=0;i<20;i++){ctx.fillStyle=`rgba(130,240,220,${.08+(i%3)*.04})`;ctx.beginPath();ctx.arc((i*127)%1000,(i*91+g.time*20)%750,3+i%5,0,Math.PI*2);ctx.fill();}}
        g.bugs.forEach((b:Entity)=>{if(!b.eaten&&!g.underwater){ctx.shadowBlur=18;ctx.shadowColor=b.kind==="firefly"?"#fff681":"#ff8d62";ctx.fillStyle=b.kind==="firefly"?"#fff681":"#2d1726";ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#fff9";ctx.fillRect(b.x-13,b.y-4,9,5);ctx.fillRect(b.x+4,b.y-4,9,5);}});
        const act=g.underwater?g.fish:g.predators;act.forEach((p:Entity)=>{shadow(p.x,p.y,p.r);ctx.font=`${p.r*1.8}px serif`;ctx.textAlign="center";ctx.fillText(p.kind==="heron"?"🪿":p.kind==="snake"?"🐍":p.kind==="pike"?"🐟":"🐠",p.x,p.y+p.r*.55);});
        const f=g.fred;shadow(f.x,f.y,f.r);ctx.save();ctx.translate(f.x,f.y);const facing=f.vx<-.15?-1:1;ctx.scale(facing,1);if(g.invincible>0&&Math.floor(g.invincible/6)%2)ctx.globalAlpha=.25;
        ctx.strokeStyle="#287b3d";ctx.lineWidth=10;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-13,10);ctx.lineTo(-30,23);ctx.lineTo(-44,18);ctx.moveTo(12,10);ctx.lineTo(29,23);ctx.lineTo(43,17);ctx.stroke();
        ctx.strokeStyle="#83e85c";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-44,18);ctx.lineTo(-51,13);ctx.moveTo(-44,18);ctx.lineTo(-52,20);ctx.moveTo(-44,18);ctx.lineTo(-49,27);ctx.moveTo(43,17);ctx.lineTo(51,11);ctx.moveTo(43,17);ctx.lineTo(52,19);ctx.moveTo(43,17);ctx.lineTo(49,26);ctx.stroke();
        const bodyGrad=ctx.createRadialGradient(-8,-10,3,0,3,31);bodyGrad.addColorStop(0,"#baff72");bodyGrad.addColorStop(1,"#3cae45");ctx.fillStyle=bodyGrad;ctx.beginPath();ctx.ellipse(0,5,28,23,0,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.ellipse(0,-12,24,18,0,0,Math.PI*2);ctx.fill();
        [-13,13].forEach(ex=>{ctx.fillStyle="#75d94e";ctx.beginPath();ctx.arc(ex,-26,11,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff9d7";ctx.beginPath();ctx.arc(ex,-27,7,0,Math.PI*2);ctx.fill();ctx.fillStyle="#172b19";ctx.beginPath();ctx.ellipse(ex+facing*1,-27,2.8,5,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(ex,-30,1.4,0,Math.PI*2);ctx.fill();});
        ctx.fillStyle="#267b37";ctx.beginPath();ctx.arc(-5,-15,1.5,0,Math.PI*2);ctx.arc(5,-15,1.5,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#184f2c";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,-10,12,.18,Math.PI-.18);ctx.stroke();ctx.fillStyle="#d7ff89";ctx.beginPath();ctx.ellipse(0,8,13,12,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#267b37";ctx.beginPath();ctx.arc(-18,2,3,0,Math.PI*2);ctx.arc(17,5,2.5,0,Math.PI*2);ctx.arc(-10,15,2,0,Math.PI*2);ctx.fill();ctx.restore();
        ctx.font="800 13px system-ui";ctx.textAlign="center";ctx.fillStyle="#fff";ctx.fillText("FRED",f.x,f.y-43);
        ctx.strokeStyle="#d8ff9a";ctx.lineWidth=3;ctx.setLineDash([8,8]);ctx.beginPath();ctx.arc(g.target.x,g.target.y,18+Math.sin(g.pulse*.1)*4,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);
        if(g.bugCount>=4){ctx.shadowBlur=30;ctx.shadowColor="#f7ed78";ctx.fillStyle="#fff59b";ctx.beginPath();ctx.arc(950,70,28,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#183f3b";ctx.font="24px serif";ctx.fillText("✦",950,79);}
        if(g.chapter===2){ctx.fillStyle="#e8943a";ctx.font="42px serif";ctx.fillText("🌰",510,630);}
        if(g.chapter===5){ctx.shadowBlur=35;ctx.shadowColor="#fff59b";ctx.fillStyle="#fff8b0";ctx.font="54px serif";ctx.fillText("✿",500,72);ctx.shadowBlur=0;}
      }
      ctx.restore();raf=requestAnimationFrame(draw);
    };raf=requestAnimationFrame(draw);
    return()=>{cancelAnimationFrame(raf);window.removeEventListener("resize",resize);canvas.removeEventListener("pointerdown",pointer);window.removeEventListener("keydown",kd);window.removeEventListener("keyup",ku);};
  },[mode]);

  const action=(key:string,on:boolean)=>{if(gameRef.current)gameRef.current.keys[key]=on;};
  const dive=(value:boolean)=>{if(gameRef.current){gameRef.current.underwater=value;setUnderwater(value);setMessage(value?"Below the surface: dodge fish and search the pond floor":"Back in the reeds — watch the sky!");}};

  return <main className="shell">
    <canvas ref={canvasRef} aria-label="Fred Myers adventure game pond" />
    <div className="vignette" />
    <header className="hud">
      <div className="brand"><span>FRED MYERS</span><small>and the Moonpetal Marsh</small></div>
      {mode==="playing"&&<><div className="chapter"><b>LEVEL {chapter} OF 5</b><span>{message}</span></div><div className="stats"><span>♥ {hearts}</span><span>🪰 {bugs}</span><div className="energy"><i style={{width:`${energy}%`}}/><b>BOOST {energy}</b></div></div></>}
    </header>
    {mode==="title"&&<section className="card intro"><p className="eyebrow">A tiny frog. A very big night.</p><h1>THE MARSH<br/><em>IS CALLING</em></h1><p>Fred Myers must recover the Sunken Acorn before dawn—or his family’s pond will lose its magic forever.</p><button onClick={startGame}>BEGIN THE ADVENTURE <span>→</span></button><div className="tips"><span>⌖ Click / tap to travel & eat</span><span>⌨ Arrow keys / WASD to steer</span><span>⚡ Hold Space / Shift to boost</span></div></section>}
    {mode==="won"&&<section className="card result"><p className="eyebrow">The pond remembers</p><h1>DAWN<br/><em>RETURNS</em></h1><p>Fred placed the Sunken Acorn beneath the Moonpetal. Every lily opened at once—and Grandmother Moss finally smiled.</p><button onClick={startGame}>PLAY AGAIN</button></section>}
    {mode==="lost"&&<section className="card result"><p className="eyebrow">A narrow escape... almost</p><h1>FRED GOT<br/><em>GOBBLED</em></h1><p>The marsh is dangerous, but every great frog tries another route.</p><button onClick={startGame}>TRY AGAIN</button></section>}
    {mode==="playing"&&levelFlash&&<div className="levelFlash"><span>{levelFlash}</span><small>{chapter===1?"THE JOURNEY BEGINS":chapter===2?"DIVE BENEATH THE LILIES":chapter===3?"FOLLOW THE LIGHTS":chapter===4?"OUTRUN THE HUNTERS":"ONE LAST LEAP"}</small></div>}
    {mode==="playing"&&<><div className="depth"><button className={!underwater?"active":""} onClick={()=>dive(false)}>☀ SURFACE</button><button className={underwater?"active":""} onClick={()=>dive(true)}>◉ DIVE</button></div><div className="touch" aria-label="Touch controls"><div className="dpad"><button onPointerDown={()=>action("arrowup",true)} onPointerUp={()=>action("arrowup",false)}>▲</button><button onPointerDown={()=>action("arrowleft",true)} onPointerUp={()=>action("arrowleft",false)}>◀</button><button onPointerDown={()=>action("arrowdown",true)} onPointerUp={()=>action("arrowdown",false)}>▼</button><button onPointerDown={()=>action("arrowright",true)} onPointerUp={()=>action("arrowright",false)}>▶</button></div><button className="boost" onPointerDown={()=>action(" ",true)} onPointerUp={()=>action(" ",false)}>BOOST</button></div></>}
    <footer><span>Keep moving. The marsh is watching.</span><b>{underwater?"BELOW THE SURFACE":"MOONPETAL MARSH"}</b></footer>
  </main>;
}
